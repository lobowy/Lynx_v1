// Lynx API worker: waitlist (D1), cached public reads from Supabase (KV).
// Chat itself does NOT go through this worker: clients talk to Supabase directly
// (Row Level Security + Realtime), see README.

const json = (body, status = 200, headers = {}) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { 'content-type': 'application/json', ...headers },
  });

const corsHeaders = (env) => ({
  'access-control-allow-origin': env.ALLOWED_ORIGIN,
  'access-control-allow-methods': 'GET,POST,PUT,OPTIONS',
  'access-control-allow-headers': 'content-type,authorization',
  vary: 'Origin',
});

// Simple fixed-window limiter in KV (approximate, fine for abuse control).
async function allow(env, key, max, ttl) {
  const k = 'rl:' + key;
  const n = parseInt((await env.CACHE.get(k)) || '0', 10);
  if (n >= max) return false;
  await env.CACHE.put(k, String(n + 1), { expirationTtl: ttl });
  return true;
}

// Cached read from Supabase REST using the publishable key (RLS still applies).
async function cachedRead(env, path, ttl) {
  const ck = 'sb:' + path;
  const hit = await env.CACHE.get(ck);
  if (hit) return hit;
  const r = await fetch(`${env.SUPABASE_URL}/rest/v1/${path}`, {
    headers: { apikey: env.SUPABASE_PUBLISHABLE_KEY },
  });
  if (!r.ok) throw new Error('upstream ' + r.status);
  const text = await r.text();
  await env.CACHE.put(ck, text, { expirationTtl: Math.max(ttl, 60) });
  return text;
}

const log = (env, ctx, kind, detail) =>
  ctx.waitUntil(
    env.DB.prepare('INSERT INTO edge_events (kind, detail) VALUES (?, ?)')
      .bind(kind, detail || null)
      .run()
      .catch(() => {})
  );

const MAX = 2 * 1024 * 1024;
const EXT = { 'image/png': 'png', 'image/jpeg': 'jpg', 'image/gif': 'gif', 'image/webp': 'webp' };
const SIGS = {
  'image/png': [[0, [0x89, 0x50, 0x4e, 0x47]]],
  'image/jpeg': [[0, [0xff, 0xd8, 0xff]]],
  'image/gif': [[0, [0x47, 0x49, 0x46, 0x38]]],
  'image/webp': [[0, [0x52, 0x49, 0x46, 0x46]], [8, [0x57, 0x45, 0x42, 0x50]]],
};
// Check the real file header, not just the claimed type.
const sigOk = (type, b) => (SIGS[type] || [[0, [-1]]]).every(([o, sig]) => sig.every((v, i) => b[o + i] === v));

// Verify the caller's Supabase session and return their user id.
async function userId(req, env) {
  const a = req.headers.get('authorization') || '';
  if (!a.startsWith('Bearer ')) return null;
  const r = await fetch(env.SUPABASE_URL + '/auth/v1/user', {
    headers: { apikey: env.SUPABASE_PUBLISHABLE_KEY, authorization: a },
  });
  if (!r.ok) return null;
  const u = await r.json();
  return (u && u.id) || null;
}

const EMAIL = /^[^\s@]{1,64}@[^\s@]{1,190}\.[^\s@]{2,}$/;

export default {
  async fetch(req, env, ctx) {
    const h = corsHeaders(env);
    const url = new URL(req.url);
    if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: h });

    try {
      if (url.pathname === '/api/health') return json({ ok: true }, 200, h);

      if (req.method === 'GET' && url.pathname === '/api/callouts') {
        const body = await cachedRead(
          env,
          'callouts?select=id,ticker,body,created_at,profiles(username,verified)&order=created_at.desc&limit=30',
          60
        );
        return new Response(body, {
          headers: { 'content-type': 'application/json', 'cache-control': 'public, max-age=30', ...h },
        });
      }

      if (req.method === 'GET' && url.pathname === '/api/channels') {
        const body = await cachedRead(env, 'channels?select=id,slug,description&order=slug', 300);
        return new Response(body, {
          headers: { 'content-type': 'application/json', 'cache-control': 'public, max-age=120', ...h },
        });
      }

      if (req.method === 'POST' && url.pathname === '/api/waitlist') {
        if (Number(req.headers.get('content-length') || 0) > 2048) return json({ error: 'Too large' }, 413, h);
        const ip = req.headers.get('CF-Connecting-IP') || 'unknown';
        if (!(await allow(env, 'wl:' + ip, 5, 3600))) return json({ error: 'Too many requests' }, 429, h);
        let data;
        try { data = await req.json(); } catch { return json({ error: 'Invalid JSON' }, 400, h); }
        if (data.website) return json({ ok: true }, 200, h); // honeypot: pretend success
        const email = String(data.email || '').trim().toLowerCase();
        if (!EMAIL.test(email) || email.length > 254) return json({ error: 'Enter a valid email' }, 400, h);
        await env.DB.prepare('INSERT OR IGNORE INTO waitlist (email, source) VALUES (?, ?)')
          .bind(email, String(data.source || 'site').slice(0, 40))
          .run();
        log(env, ctx, 'waitlist_signup');
        return json({ ok: true }, 200, h);
      }

      if (req.method === 'PUT' && url.pathname === '/api/upload') {
        const uid = await userId(req, env);
        if (!uid) return json({ error: 'Sign in required' }, 401, h);
        const kind = url.searchParams.get('kind');
        if (kind !== 'avatar' && kind !== 'banner') return json({ error: 'kind must be avatar or banner' }, 400, h);
        const type = (req.headers.get('content-type') || '').split(';')[0].trim();
        if (!EXT[type]) return json({ error: 'PNG, JPG, WebP or GIF only' }, 415, h);
        const cl = Number(req.headers.get('content-length'));
        if (!cl || cl > MAX) return json({ error: 'Max 2 MB' }, 413, h);
        if (!(await allow(env, 'up:' + uid, 20, 3600))) return json({ error: 'Too many uploads' }, 429, h);
        const buf = await req.arrayBuffer();
        if (buf.byteLength === 0 || buf.byteLength > MAX) return json({ error: 'Max 2 MB' }, 413, h);
        if (!sigOk(type, new Uint8Array(buf, 0, Math.min(16, buf.byteLength)))) return json({ error: 'File does not match its type' }, 415, h);
        const key = `${uid}/${kind}-${crypto.randomUUID()}.${EXT[type]}`;
        await env.MEDIA.put(key, buf, { httpMetadata: { contentType: type } });
        log(env, ctx, 'upload', kind);
        return json({ key, url: `${url.origin}/api/media/${key}` }, 201, h);
      }

      if (req.method === 'GET' && url.pathname.startsWith('/api/media/')) {
        const key = decodeURIComponent(url.pathname.slice('/api/media/'.length));
        if (!/^[0-9a-f-]{36}\/(avatar|banner)-[0-9a-f-]{36}\.(png|jpg|gif|webp)$/.test(key)) return json({ error: 'Not found' }, 404, h);
        const o = await env.MEDIA.get(key);
        if (!o) return json({ error: 'Not found' }, 404, h);
        return new Response(o.body, {
          headers: { 'content-type': o.httpMetadata.contentType, 'cache-control': 'public, max-age=31536000, immutable', 'x-content-type-options': 'nosniff', ...h },
        });
      }

      return json({ error: 'Not found' }, 404, h);
    } catch (e) {
      log(env, ctx, 'error', String(e && e.message).slice(0, 200));
      return json({ error: 'Something went wrong' }, 500, h);
    }
  },
};
